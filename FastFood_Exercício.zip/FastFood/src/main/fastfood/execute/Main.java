package main.fastfood.execute;

import main.fastfood.model.Cliente;
import main.fastfood.model.Endereco;
import main.fastfood.model.Estabelecimento;

public class Main {

	public static void main(String[] args) {
		
		
			
		

	}

}
